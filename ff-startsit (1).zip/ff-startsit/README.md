# Half-PPR Start / Sit

Python + Streamlit tool that:

- Pulls Sleeper weekly projections (Half-PPR)
- Adjusts them by **defense vs position**
- Ranks start / lean start / toss-up / lean sit / sit
- Shows the next 1–4 weeks with opponent + DVP rank
- Optionally filters to your **Sleeper** roster and/or **ESPN** roster

## Setup

```bash
cd ff-startsit
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

## Sleeper

Enter your Sleeper username. The app lists your 2026 NFL leagues and loads that roster.

## ESPN

1. Public league: ESPN league ID + your team name.
2. Private league: also paste `espn_s2` and `SWID` cookies.

Get cookies:

1. Log into ESPN Fantasy in Chrome.
2. DevTools → Application → Cookies → `espn.com`.
3. Copy `espn_s2` and `SWID`.

Do not commit cookies.

## Defense vs position

Built from nflverse weekly player stats (`stats_player_week_{year}.csv`).

Half-PPR allowed = standard fantasy points + 0.5 × receptions, summed by the defense the player faced, then divided by games.

- Rank **1** = toughest (fewest points allowed)
- Rank **32** = easiest
- Multiplier = defense average / league average, clamped **0.80–1.20**
- `proj` = Sleeper Half-PPR × multiplier
- Before week 4: **70% last season + 30% current season**
- Week 4 onward: current season only

The board shows `opp`, `matchup` (Easy/Avg/Tough + rank), and `dvp_rank`. A full DVP table sits under the board.

## Scoring

Hard-coded Half-PPR:

- 0.5 points per reception
- 0.1 per rush/rec yard
- 6 rush/rec TD, 4 pass TD
- −2 INT / fumble lost
- 0.04 per pass yard

If Sleeper already sends `pts_half_ppr`, that value is used first.

## Next upgrades

- Weather / Vegas total adjustment
- Direct player-vs-player compare box
- Save league IDs locally so you do not re-enter them
