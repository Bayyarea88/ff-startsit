"""Half-PPR start/sit labels from projected points + matchup + availability."""

from __future__ import annotations

from typing import Literal

Call = Literal["Strong Start", "Lean Start", "Toss-up", "Lean Sit", "Sit"]


def matchup_multiplier(def_pts_allowed: float | None, league_avg: float | None) -> float:
    if not def_pts_allowed or not league_avg or league_avg <= 0:
        return 1.0
    ratio = def_pts_allowed / league_avg
    return max(0.80, min(1.20, ratio))


def label_from_points(pts: float, pos_median: float) -> Call:
    gap = pts - pos_median
    if gap >= 4:
        return "Strong Start"
    if gap >= 1.5:
        return "Lean Start"
    if gap <= -4:
        return "Sit"
    if gap <= -1.5:
        return "Lean Sit"
    return "Toss-up"


def compare_two(a_pts: float, b_pts: float) -> str:
    diff = a_pts - b_pts
    if abs(diff) < 1.5:
        return f"Toss-up ({diff:+.1f})"
    winner = "A" if diff > 0 else "B"
    strength = "start" if abs(diff) < 4 else "strong start"
    return f"{strength.title()} {winner} ({diff:+.1f} Half-PPR)"
